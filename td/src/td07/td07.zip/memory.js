const game = {};
game.create = function(images, blank) {
  
};
game.build = function(div) {
  
};

const shuffleCards = function(length) {
  let cards = [];
  for(let i = 0; i < length; i++) {
    cards.push(i);
    cards.push(i);
  }
  return cards;
};
