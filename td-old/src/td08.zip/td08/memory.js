class MemoryGame {
  constructor(images, blank) {
    // TODO
  }
  build(div) {
  // TODO
  }
}

function shuffleCards(length) {
  var cards = [];
  for(var i = 0; i < length; i++) {
    cards.push(i);
    cards.push(i);
  }
  return cards;
}
