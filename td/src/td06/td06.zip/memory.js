class MemoryGame {
  constructor(images, blank) {
    // TODO
  }
  build(div) {
  // TODO
  }
}

const shuffleCards = function(length) {
  let cards = [];
  for(let i = 0; i < length; i++) {
    cards.push(i);
    cards.push(i);
  }
  return cards;
};
